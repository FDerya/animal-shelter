package org.example.animalshelter;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AnimalshelterApplicationTests {

	@Test
	void contextLoads() {
	}

}
